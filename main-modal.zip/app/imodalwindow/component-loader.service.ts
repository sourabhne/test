import { Injectable } from '@angular/core';
import { Imodalbody1Component } from './imodalbody1/imodalbody1.component';
import { Imodalbody2Component } from './imodalbody2/imodalbody2.component';
import { Imodalbody3Component } from './imodalbody3/imodalbody3.component';

import { ImodalwindowModule } from './imodalwindow.module';

@Injectable({
  providedIn: 'root'
  // providedIn: ImodalwindowModule
})
export class ComponentLoaderService {

  constructor() { }

  getComponent(componentName: string) {
    
    if (componentName == "Imodalbody1Component") {
      return Imodalbody1Component;
    }
    else if (componentName == "Imodalbody2Component") {
      return Imodalbody2Component;
    }
    else if (componentName == "Imodalbody3Component") {
      return Imodalbody3Component;
    }
    else{
      return "";
    }
  }
}
