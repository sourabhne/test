import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Imodalbody1Component } from './imodalbody1.component';

describe('Imodalbody1Component', () => {
  let component: Imodalbody1Component;
  let fixture: ComponentFixture<Imodalbody1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Imodalbody1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Imodalbody1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
