import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-imodalbody3',
  templateUrl: './imodalbody3.component.html',
  styleUrls: ['./imodalbody3.component.css']
})
export class Imodalbody3Component implements OnInit {

  @Input() data: any;
  constructor() {}

  ngOnInit() {
    console.log(this.data);
  }

}
