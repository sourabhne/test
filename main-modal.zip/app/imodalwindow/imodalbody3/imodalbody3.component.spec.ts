import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Imodalbody3Component } from './imodalbody3.component';

describe('Imodalbody3Component', () => {
  let component: Imodalbody3Component;
  let fixture: ComponentFixture<Imodalbody3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Imodalbody3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Imodalbody3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
