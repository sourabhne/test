import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appImodalcontainer]'
})
export class ImodalcontainerDirective {
  constructor(public viewContainerRef: ViewContainerRef) { 

      
  }
}