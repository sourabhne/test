import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Imodalbody2Component } from './imodalbody2.component';

describe('Imodalbody2Component', () => {
  let component: Imodalbody2Component;
  let fixture: ComponentFixture<Imodalbody2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Imodalbody2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Imodalbody2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
