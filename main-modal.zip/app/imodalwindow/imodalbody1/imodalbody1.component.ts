import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-imodalbody1',
  templateUrl: './imodalbody1.component.html',
  styleUrls: ['./imodalbody1.component.css']
})
export class Imodalbody1Component implements OnInit {

  @Input() data: any;
  constructor() {}

  ngOnInit() {
    console.log(this.data);
  }

}
  