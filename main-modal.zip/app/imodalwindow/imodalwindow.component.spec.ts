import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImodalwindowComponent } from './imodalwindow.component';

describe('ImodalwindowComponent', () => {
  let component: ImodalwindowComponent;
  let fixture: ComponentFixture<ImodalwindowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImodalwindowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImodalwindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
