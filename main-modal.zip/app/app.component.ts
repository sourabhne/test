import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string="Modal window"


  ngOnInit() {
    // this.data1="The content is displayed from Demo1 component";
    // this.data2="The content is displayed from Demo2 component";
  }

}
