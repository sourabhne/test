import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-imodalbody2',
  templateUrl: './imodalbody2.component.html',
  styleUrls: ['./imodalbody2.component.css']
})
export class Imodalbody2Component implements OnInit {


  @Input() data: any;
  constructor() {}

  ngOnInit() {
    console.log(this.data);
  }

}
