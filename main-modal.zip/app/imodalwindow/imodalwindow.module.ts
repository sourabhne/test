import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImodalwindowComponent } from './imodalwindow.component';
import { ImodalwindowDirective } from './imodalwindow.directive';
import { ImodalcontainerDirective } from './imodalcontainer.directive';
import { Imodalbody2Component } from './imodalbody2/imodalbody2.component';
import { Imodalbody1Component } from './imodalbody1/imodalbody1.component';
import { Imodalbody3Component } from './imodalbody3/imodalbody3.component';

import { ComponentLoaderService } from './component-loader.service';


@NgModule({
  declarations: [ImodalwindowComponent, ImodalwindowDirective, ImodalcontainerDirective, Imodalbody2Component, Imodalbody1Component, Imodalbody3Component],
  imports: [
    CommonModule
  ],
  entryComponents: [
    ImodalwindowComponent,
    Imodalbody1Component,
    Imodalbody2Component,
    Imodalbody3Component
  ],
  providers:[ComponentLoaderService],
  exports: [ImodalwindowComponent, ImodalwindowDirective, ImodalcontainerDirective, Imodalbody2Component, Imodalbody1Component, Imodalbody3Component],
})
export class ImodalwindowModule { }
